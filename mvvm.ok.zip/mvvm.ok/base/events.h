#ifndef EVENTS_H
#define EVENTS_H

#include "gvalue.h"

typedef uint8_t EventType;
typedef uint8_t PropName;

typedef struct _Event {
	EventType type;
}Event;

typedef struct _PropChangeEvent {
	EventType type;
	PropName  prop;
	GValue* value;
}PropChangeEvent;

enum _EventType {
	EVENT_ANY = 0,
	EVENT_PROP_CHANGED = 1,
	EVENTS_NR
};

#endif//EVENTS_H 
