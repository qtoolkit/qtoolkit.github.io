#ifndef VM_CONFIG_H
#define VM_CONFIG_H

#define PRE_ALLOC_LISTENERS_NR 10

#endif//VM_CONFIG_H 

