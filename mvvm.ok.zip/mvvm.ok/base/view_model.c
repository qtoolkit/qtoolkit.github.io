#include "view_model.h"

struct _ViewModel {
	GValue* props;
	Command** cmds;
	Emitter* emitter;
	size_t max_props;
	size_t max_cmds;
	Allocator* allocator;
};

ViewModel* vm_create(Allocator* allocator, size_t max_props, size_t  max_cmds) {
	return_value_if_fail(allocator != NULL && max_props > 0 && max_cmds > 0, NULL);

	ViewModel* vm = (ViewModel*)allocator_alloc(allocator, sizeof(ViewModel));
	
	vm->max_cmds = max_cmds;
	vm->max_props = max_props;
	vm->allocator = allocator;
	vm->emitter = emitter_create(allocator);
	vm->props = (GValue*)allocator_alloc(allocator, sizeof(GValue) * max_props);
	vm->cmds = (Command**)allocator_alloc(allocator, sizeof(Command*) * max_cmds);

	return vm;
}

bool_t vm_set_prop(ViewModel* vm, PropName name, const GValue* value) {
	return_value_if_fail(vm != NULL && name < vm->max_props && value != NULL, FALSE);

	gvalue_copy((vm->props+name), value);

	if(vm->emitter) {
		PropChangeEvent e = {.type = EVENT_PROP_CHANGED, .prop = name, .value = (GValue*)value};
		emitter_emit(vm->emitter, (Event*)&e);
	}

	return TRUE;
}

bool_t vm_get_prop(ViewModel* vm, PropName name, GValue* value) {
	return_value_if_fail(vm != NULL && name < vm->max_props && value != NULL, FALSE);
	
	gvalue_copy(value, (vm->props+name));

	return TRUE;
}

errno_t vm_execute(ViewModel* vm, CommandName name, void* args) {
	return_value_if_fail(vm != NULL && name < vm->max_cmds, ERRNO_INVALID_PARAMS);
	Command* cmd = vm->cmds[name];
	return cmd_execute(cmd, args);
}

bool_t vm_can_execute(ViewModel* vm, CommandName name) {
	return_value_if_fail(vm != NULL && name < vm->max_cmds, FALSE);
	Command* cmd = vm->cmds[name];
	return cmd_can_execute(cmd);
}

bool_t vm_reg_command(ViewModel* vm, CommandName name, Command* cmd) {
	return_value_if_fail(vm != NULL && name < vm->max_cmds, FALSE);
	
	vm->cmds[name] = cmd;

	return TRUE;
}

bool_t vm_unreg_command(ViewModel* vm, CommandName name){
	return_value_if_fail(vm != NULL && name < vm->max_cmds, FALSE);
	vm->cmds[name] = NULL;

	return TRUE;
}

bool_t vm_on_change(ViewModel* vm, OnPropEventFunc callback, void* ctx) {
	return_value_if_fail(vm != NULL && callback != NULL, FALSE);
	
	return emitter_on(vm->emitter, EVENT_PROP_CHANGED, (OnEventFunc)callback, ctx);
}

bool_t vm_off_change(ViewModel* vm, OnPropEventFunc callback, void* ctx) {
	return_value_if_fail(vm != NULL && callback != NULL, FALSE);

	return emitter_off(vm->emitter, EVENT_PROP_CHANGED, (OnEventFunc)callback, ctx);
}

void vm_destroy(ViewModel* vm) {
	return_if_fail(vm != NULL && vm->allocator != NULL);
	
	Allocator* allocator = vm->allocator;
	allocator_free(allocator, vm->props);
	allocator_free(allocator, vm->cmds);
	memset(vm, 0x00, sizeof(ViewModel));

	return;
}


