#ifndef VIEW_MODEL_H
#define VIEW_MODEL_H

#include "events.h"
#include "command.h"
#include "emitter.h"
#include "allocator.h"

BEGIN_C_DECLS

typedef uint8_t ValidatorName;
typedef uint8_t ConverterName;
typedef uint8_t CommandName;

struct _ViewModel;
typedef struct _ViewModel ViewModel;

typedef void (*OnPropEventFunc)(void* ctx, PropChangeEvent* evt);

ViewModel* vm_create(Allocator* allocator, size_t max_props, size_t  max_cmds);

bool_t vm_set_prop(ViewModel* vm, PropName name, const GValue* value);
bool_t vm_get_prop(ViewModel* vm, PropName name, GValue* value);

errno_t vm_execute(ViewModel* vm, CommandName name, void* args);
bool_t vm_can_execute(ViewModel* vm, CommandName name);
bool_t vm_reg_command(ViewModel* vm, CommandName name, Command* cmd);
bool_t vm_unreg_command(ViewModel* vm, CommandName name);

bool_t vm_on_change(ViewModel* view_model, OnPropEventFunc callback, void* ctx);
bool_t vm_off_change(ViewModel* view_model, OnPropEventFunc callback, void* ctx);

void   vm_destroy(ViewModel* vm);

END_C_DECLS

#endif//VIEW_MODEL_H

