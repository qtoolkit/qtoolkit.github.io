
#include "emitter.h"
#include "config.h"

typedef struct _Listener {
	void* ctx;
	EventType type;
	OnEventFunc callback;
}Listener;

struct _Emitter {
	size_t nr;
	Allocator* allocator;
	Listener* listeners;
};

typedef bool_t (*ListenerVisitFunc)(Emitter* emitter, Listener* listener, void* ctx);

static bool_t emitter_foreach(Emitter* emitter, ListenerVisitFunc visit, void* ctx) {
	return_value_if_fail(emitter != NULL && visit != NULL, FALSE);

	size_t nr = emitter->nr;
	Listener* listeners = emitter->listeners;
	for(size_t i = 0; i < nr; i++) {
		Listener* iter = &listeners[i];
		if(visit(emitter, iter, ctx)) {
			return TRUE;
		}
	}

	return FALSE;
}

static bool_t emitter_clear_listeners(Emitter* emitter, Listener* listener, void* ctx) {
	(void)ctx;
	(void)emitter;
	listener->callback = NULL;
	return FALSE;
}

Emitter* emitter_create(Allocator* allocator) {
	size_t nr = PRE_ALLOC_LISTENERS_NR;
	Emitter* emitter   = allocator_alloc(allocator, sizeof(Emitter));
	emitter->listeners = allocator_alloc(allocator, nr * sizeof(Listener));
	emitter->allocator = allocator;
	emitter->nr = nr;
	
	emitter_foreach(emitter, emitter_clear_listeners, NULL);
	
	return emitter;
}

static bool_t emitter_add_listener(Emitter* emitter, Listener* listener, void* ctx) {
	(void)emitter;
	if(!listener->callback) {
		memcpy(listener, ctx, sizeof(Listener));
		return TRUE;
	}

	return FALSE;	
}

static bool_t emitter_extend(Emitter* emitter) {
	size_t nr = emitter_count(emitter, EVENT_ANY);

	if(nr == emitter->nr) {
		nr = nr + 3;
		size_t size = nr * sizeof(Listener);
		Listener* listeners = (Listener*)allocator_realloc(emitter->allocator, emitter->listeners, size);
		if(listeners) {
			emitter->listeners = listeners;
			for(size_t i = emitter->nr; i < nr; i++) {
				memset(listeners+i, 0x00, sizeof(Listener));
			}
			emitter->nr = nr;
		}
	}

	return TRUE;
}

bool_t emitter_on(Emitter* emitter, EventType type, OnEventFunc callback, void* ctx) {
	Listener listener = {.ctx = ctx, .type = type, .callback = callback};
	
	emitter_extend(emitter);
	return emitter_foreach(emitter, emitter_add_listener, &listener);
}

static bool_t emitter_remove_listener(Emitter* emitter, Listener* listener, void* ctx) {
	(void)emitter;
	Listener* l = (Listener*)ctx;
	if(listener->type == l->type && listener->ctx == l->ctx && listener->callback == l->callback) {
		listener->callback = NULL;
		return TRUE;
	}
	return FALSE;	
}

bool_t emitter_off(Emitter* emitter, EventType type, OnEventFunc callback, void* ctx) {
	Listener listener = {.ctx = ctx, .type = type, .callback = callback};
	return emitter_foreach(emitter, emitter_remove_listener, &listener);
}

static bool_t emitter_dispatch_event(Emitter* emitter, Listener* listener, void* ctx) {
	(void)emitter;
	Event* evt = (Event*)ctx;
	if(listener->type == evt->type && listener->callback) {
		listener->callback(listener->ctx, evt);
	}

	return FALSE;
}

typedef struct _CountInfo {
	EventType type;
	size_t count;
}CountInfo;

static bool_t emitter_count_listenters(Emitter* emitter, Listener* listener, void* ctx) {
	(void)emitter;
	CountInfo* info = (CountInfo*)ctx;
	if(listener->callback && (listener->type == info->type || info->type == EVENT_ANY)) {
		info->count += 1;
	}
	return FALSE;
}

size_t emitter_count(Emitter* emitter, EventType type) {
	CountInfo info = {.type = type, .count = 0};
	emitter_foreach(emitter, emitter_count_listenters, &info);

	return info.count;
}

void emitter_emit(Emitter* emitter, Event* evt) {
	emitter_foreach(emitter, emitter_dispatch_event, evt);
}

void emitter_destroy(Emitter* emitter) {
	size_t size = sizeof(Emitter);
	allocator_free(emitter->allocator, emitter->listeners);
	allocator_free(emitter->allocator, emitter);
	memset(emitter, 0x00, size);
}


