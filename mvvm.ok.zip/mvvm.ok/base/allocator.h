#ifndef ALLOCATOR_H
#define ALLOCATOR_H 
#include "types_def.h"

BEGIN_C_DECLS

struct _Allocator;
typedef struct _Allocator Allocator;

typedef void  (*AllocatorFree)(Allocator* allocator, void* addr);
typedef void* (*AllocatorAlloc)(Allocator* allocator, size_t size);
typedef void* (*AllocatorCalloc)(Allocator* allocator, size_t num, size_t size);
typedef void* (*AllocatorRealloc)(Allocator* allocator, void* addr, size_t size);

struct _Allocator {
	AllocatorFree free;
	AllocatorAlloc alloc;
	AllocatorCalloc calloc;
	AllocatorRealloc realloc;
};

Allocator* allocator_default();
void allocator_debug_info();
bool_t allocator_init(void* addr, size_t size);

static inline void allocator_free(Allocator* allocator, void* addr) {
	return_if_fail(allocator != NULL && allocator->free != NULL);

	allocator->free(allocator, addr);
}

static inline void* allocator_alloc(Allocator* allocator, size_t size) {
	return_value_if_fail(allocator != NULL && allocator->alloc != NULL, NULL);

	return allocator->alloc(allocator, size);
}

static inline void* allocator_calloc(Allocator* allocator, size_t num, size_t size) {
	return_value_if_fail(allocator != NULL && allocator->calloc != NULL, NULL);

	return allocator->calloc(allocator, num, size);
}

static inline void* allocator_realloc(Allocator* allocator, void* addr, size_t size) {
	return_value_if_fail(allocator != NULL && allocator->realloc != NULL, NULL);

	return allocator->realloc(allocator, addr, size);
}

END_C_DECLS

#endif//ALLOCATOR_H
