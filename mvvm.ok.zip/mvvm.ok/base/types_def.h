#ifndef TYPES_DEF_H
#define TYPES_DEF_H 
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

typedef int bool_t;
typedef float float32_t;
typedef double floa64_t;
typedef void* pointer_t;

#ifdef WIN32
typedef int __int32_t;
typedef char __int8_t;
typedef short __int16_t;
typedef unsigned int __uint32_t;
typedef unsigned char __uint8_t;
typedef unsigned short __uint16_t;
#endif//WIN32

#ifndef _INT8_T_DECLARED
typedef __int8_t int8_t ;
#define _INT8_T_DECLARED
#endif
#ifndef _UINT8_T_DECLARED
typedef __uint8_t uint8_t ;
#define _UINT8_T_DECLARED
#endif

#ifndef _INT16_T_DECLARED
typedef __int16_t int16_t ;
#define _INT16_T_DECLARED
#endif
#ifndef _UINT16_T_DECLARED
typedef __uint16_t uint16_t ;
#define _UINT16_T_DECLARED
#endif

#ifndef _INT32_T_DECLARED
typedef __int32_t int32_t ;
#define _INT32_T_DECLARED
#endif
#ifndef _UINT32_T_DECLARED
typedef __uint32_t uint32_t ;
#define _UINT32_T_DECLARED
#endif

#ifndef _INT64_T_DECLARED
typedef __int64_t int64_t ;
#define _INT64_T_DECLARED
#endif
#ifndef _UINT64_T_DECLARED
typedef __uint64_t uint64_t ;
#define _UINT64_T_DECLARED
#endif

#ifndef errno_t
typedef int errno_t;
#endif

#define ERRNO_OK 0
#define ERRNO_FAIL -1
#define ERRNO_NO_SPACE -2
#define ERRNO_NOT_FOUND -3
#define ERRNO_INVALID_PARAMS -4

#ifndef TRUE
#	define TRUE 1
#endif
#ifndef FALSE
#	define FALSE 0
#endif

#ifdef __cplusplus
#	define BEGIN_C_DECLS extern "C" {
#	define END_C_DECLS }
#else
#	define BEGIN_C_DECLS
#	define END_C_DECLS
#endif

typedef void (*GObjectDestroyFunc)(void* obj);

typedef struct _GObject {
	GObjectDestroyFunc destroy;
	void* obj;
}GObject;

static inline GObject gobject_init(GObjectDestroyFunc destroy, void* obj) {
	GObject gobject = {.destroy = destroy, .obj = obj};
	
	return gobject;
}

#ifdef NDEBUG
#	define return_if_fail(p) if(!(p)) {return;}
#	define return_value_if_fail(p, value) if(!(p)) {return (value);}
#else
#	define return_if_fail(p) if(!(p)) \
	{printf("%s:%s:%d conditions not meet\n", __FILE__, __FUNCTION__, __LINE__); return;}
#	define return_value_if_fail(p, value) if(!(p)) \
	{printf("%s:%s:%d conditions not meet\n", __FILE__, __FUNCTION__, __LINE__); return (value);}
#endif

#endif//TYPES_DEF_H 
