#include "allocator.h"
#include "umm_malloc.h"

static void def_free(Allocator* allocator, void* addr) {
	(void)allocator;
	umm_free(addr);
}

static void* def_malloc(Allocator* allocator, size_t size) {
	(void)allocator;
	return umm_malloc(size);
}

static void* def_calloc(Allocator* allocator, size_t num, size_t size) {
	(void)allocator;
	return umm_calloc(num, size);
}

static void* def_realloc(Allocator* allocator, void* addr, size_t size) {
	(void)allocator;
	return umm_realloc(addr, size);
}

static Allocator allocator = {
	.free  = def_free,
	.alloc = def_malloc,
	.calloc = def_calloc,
	.realloc = def_realloc
};

Allocator* allocator_default() {
	return &allocator;
}

bool_t allocator_init(void* addr, size_t size) {
	return_value_if_fail(addr != NULL && size != 0, FALSE);

	umm_init(addr, size);

	return TRUE;
}

void allocator_debug_info() {
	printf("free heap size:%zu\n", umm_free_heap_size());
}
