#include <assert.h>
#include "types_def.h"

#ifndef G_VALUE_H
#define G_VALUE_H 

typedef enum _GValueType {
	GVALUE_TYPE_INVALID = 0,
	GVALUE_TYPE_INT8,
	GVALUE_TYPE_UINT8,
	GVALUE_TYPE_INT16,
	GVALUE_TYPE_UINT16,
	GVALUE_TYPE_INT32,
	GVALUE_TYPE_UINT32,
	GVALUE_TYPE_POINTER,
	GVALUE_TYPE_FLOAT32,
	GVALUE_TYPE_FLOAT64,
	GVALUE_TYPE_OBJECT
}GValueType;

typedef struct _GValue {
	GValueType type;
	union {
		int8_t int8Value;
		uint8_t uint8Value;
		int16_t int16Value;
		uint16_t uint16Value;
		int32_t int32Value;
		uint32_t uint32Value;
		pointer_t pointerValue;
		float32_t float32Value;
		floa64_t float64Value;
		GObject* objectValue;
	}value;
}GValue;

static inline void gvalue_init_with_int8(GValue* gv, int8_t value) {
	assert(gv != NULL);
	gv->type = GVALUE_TYPE_INT8;
	gv->value.int8Value = value;
}

static inline int8_t gvalue_get_int8(GValue* gv) {
	assert(gv != NULL && gv->type == GVALUE_TYPE_INT8);
	return gv->value.int8Value;
}

static inline void gvalue_init_with_uint8(GValue* gv, uint8_t value) {
	assert(gv != NULL);
	gv->type = GVALUE_TYPE_UINT8;
	gv->value.uint8Value = value;
}

static inline uint8_t gvalue_get_uint8(GValue* gv) {
	assert(gv != NULL && gv->type == GVALUE_TYPE_UINT8);
	return gv->value.uint8Value;
}

static inline void gvalue_init_with_int16(GValue* gv, int16_t value) {
	assert(gv != NULL);
	gv->type = GVALUE_TYPE_INT16;
	gv->value.int16Value = value;
}

static inline int16_t gvalue_get_int16(GValue* gv) {
	assert(gv != NULL && gv->type == GVALUE_TYPE_INT16);
	return gv->value.int16Value;
}

static inline void gvalue_init_with_uint16(GValue* gv, uint16_t value) {
	assert(gv != NULL);
	gv->type = GVALUE_TYPE_UINT16;
	gv->value.uint16Value = value;
}

static inline uint16_t gvalue_get_uint16(GValue* gv) {
	assert(gv != NULL && gv->type == GVALUE_TYPE_UINT16);
	return gv->value.uint16Value;
}

static inline void gvalue_init_with_int32(GValue* gv, int32_t value) {
	assert(gv != NULL);
	gv->type = GVALUE_TYPE_INT32;
	gv->value.int32Value = value;
}

static inline int32_t gvalue_get_int32(GValue* gv) {
	assert(gv != NULL && gv->type == GVALUE_TYPE_INT32);
	return gv->value.int32Value;
}

static inline void gvalue_init_with_uint32(GValue* gv, uint32_t value) {
	assert(gv != NULL);
	gv->type = GVALUE_TYPE_UINT32;
	gv->value.uint32Value = value;
}

static inline uint32_t gvalue_get_uint32(GValue* gv) {
	assert(gv != NULL && gv->type == GVALUE_TYPE_UINT32);
	return gv->value.uint32Value;
}

static inline void gvalue_init_with_pointer(GValue* gv, pointer_t value) {
	assert(gv != NULL);
	gv->type = GVALUE_TYPE_POINTER;
	gv->value.pointerValue = value;
}

static inline pointer_t gvalue_get_pointer(GValue* gv) {
	assert(gv != NULL && gv->type == GVALUE_TYPE_POINTER);
	return gv->value.pointerValue;
}

static inline void gvalue_init_with_float32(GValue* gv, float32_t value) {
	assert(gv != NULL);
	gv->type = GVALUE_TYPE_FLOAT32;
	gv->value.float32Value = value;
}

static inline float32_t gvalue_get_float32(GValue* gv) {
	assert(gv != NULL && gv->type == GVALUE_TYPE_FLOAT32);
	return gv->value.float32Value;
}

static inline void gvalue_init_with_float64(GValue* gv, floa64_t value) {
	assert(gv != NULL);
	gv->type = GVALUE_TYPE_FLOAT64;
	gv->value.float64Value = value;
}

static inline floa64_t gvalue_get_float64(GValue* gv) {
	assert(gv != NULL && gv->type == GVALUE_TYPE_FLOAT64);
	return gv->value.float64Value;
}

static inline void gvalue_init_with_object(GValue* gv, GObject* value) {
	assert(gv != NULL);
	gv->type = GVALUE_TYPE_OBJECT;
	gv->value.objectValue = value;
}

static inline GObject* gvalue_get_object(GValue* gv) {
	assert(gv != NULL && gv->type == GVALUE_TYPE_OBJECT);
	return gv->value.objectValue;
}

static inline void gvalue_copy(GValue* dst, const GValue* src) {
	memcpy(dst, src, sizeof(GValue));
}

#endif
