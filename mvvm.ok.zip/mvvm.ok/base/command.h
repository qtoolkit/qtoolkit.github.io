#ifndef COMMAND_H
#define COMMAND_H
#include "types_def.h"

BEGIN_C_DECLS 

struct _Command;
typedef struct _Command Command;

typedef bool_t (*CanExecuteFunc)(Command* cmd);
typedef errno_t (*ExecuteFunc)(Command* cmd, void* args);

struct _Command {
	void* ctx;
	ExecuteFunc execute;
	CanExecuteFunc can_execute;
};

static inline bool_t cmd_init(Command* cmd, ExecuteFunc execute, CanExecuteFunc can_execute, void* ctx) {
	return_value_if_fail(cmd != NULL && execute != NULL, FALSE);

	cmd->ctx = ctx;
	cmd->execute = execute;
	cmd->can_execute = can_execute;

	return TRUE;
}

static inline errno_t cmd_execute(Command* cmd, void* args) {
	return_value_if_fail(cmd != NULL && cmd->execute != NULL, ERRNO_INVALID_PARAMS);
	
	return cmd->execute(cmd, args);
}

static inline bool_t cmd_can_execute(Command* cmd) {
	return_value_if_fail(cmd != NULL, FALSE);
	
	return cmd->can_execute ? cmd->can_execute(cmd) : TRUE;
}

END_C_DECLS 

#endif

