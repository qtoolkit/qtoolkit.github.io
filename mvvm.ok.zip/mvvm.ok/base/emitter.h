#ifndef EMITTER_H
#define EMITTER_H

#include "events.h"
#include "allocator.h"

BEGIN_C_DECLS

struct _Emitter;
typedef struct _Emitter Emitter;
typedef void (*OnEventFunc)(void* ctx, Event* evt);

Emitter* emitter_create(Allocator* allocator);
bool_t emitter_on(Emitter* emitter, EventType type, OnEventFunc callback, void* ctx);
bool_t emitter_off(Emitter* emitter, EventType type, OnEventFunc callback, void* ctx);
size_t emitter_count(Emitter* emitter, EventType type);
void emitter_emit(Emitter* emitter, Event* evt);
void emitter_destroy(Emitter* emitter);

END_C_DECLS

#endif//EMITTER_H
