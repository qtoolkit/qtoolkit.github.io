Model-View-ViewModel(MVVM)在嵌入式系统中的实现
-----------------------------------------------

目录结构介绍
----------------------
base MVVM的框架代码。
app	 一个基于MVVM框架的门禁系统DEMO。
tests 单元测试程序
3rd	  第三方库，目前有googletest单元测试框架。

代码大小(arm-none-eabi-gcc)
----------------------
不优化代码段约13K：
arm-none-eabi-objdump -h libmvvm.so |grep text
7 .text         000033bc  00000b68  00000b68  00000b68  2**2

加-Os优化代码段约6K：
arm-none-eabi-objdump -h libmvvm.so |grep text
7 .text         00001738  00000b68  00000b68  00000b68  2**2

内存开销
----------------------
在DEMO中：
 *.1个属性
 *.10个视图
 *.16个命令
MVVM的框架需要512个字节。每增加一个视图或命令，大约增加20个字节的开销。
