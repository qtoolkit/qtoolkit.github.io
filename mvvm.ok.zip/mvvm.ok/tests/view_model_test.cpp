#include <stdio.h>
#include <stdlib.h>
#include "gtest/gtest.h"
#include "view_model.h"

static char mem[1024] = {0};

enum {
	PROP0 = 0,
	PROP1,
	PROP_NR,
	INVALID_PROP = 100
};

enum {
	CMD_TEST0 = 0,
	CMD_TEST1,
	CMD_NR,
	INVALID_CMD = 100
};

#define PROP0_VALUE 123
#define PROP1_VALUE 456

class ViewModelTest: public testing::Test {
protected:
	virtual void SetUp() {
		memset(mem, 0x00, sizeof(mem));
		allocator_init(mem, sizeof(mem));
		this->vm = vm_create(allocator_default(), PROP_NR, CMD_NR); 
	}

	virtual void TearDown() {
		vm_destroy(this->vm);
	}

	ViewModel* vm;
};

TEST_F(ViewModelTest, setGetProp0) {
	GValue value;
	gvalue_init_with_int32(&value, PROP0_VALUE);
	ASSERT_EQ(TRUE, vm_set_prop(this->vm, PROP0, &value));
	ASSERT_EQ(TRUE, vm_get_prop(this->vm, PROP0, &value));
	ASSERT_EQ(PROP0_VALUE, gvalue_get_int32(&value));
}

TEST_F(ViewModelTest, setGetProp1) {
	GValue value;
	gvalue_init_with_int32(&value, PROP1_VALUE);
	ASSERT_EQ(TRUE, vm_set_prop(this->vm, PROP1, &value));
	ASSERT_EQ(TRUE, vm_get_prop(this->vm, PROP1, &value));
	ASSERT_EQ(PROP1_VALUE, gvalue_get_int32(&value));
}

TEST_F(ViewModelTest, setGetPropFail) {
	ASSERT_EQ(FALSE, vm_set_prop(this->vm, INVALID_PROP, NULL));
	ASSERT_EQ(FALSE, vm_get_prop(this->vm, INVALID_PROP, NULL));
}

static errno_t set_str(Command* cmd, void* args) {
	cmd->ctx = args;
	return ERRNO_OK;
}

static bool_t can_set_str_if_not_set(Command* cmd) {
	return !cmd->ctx;
}

TEST_F(ViewModelTest, regUnRegCommand) {
	Command cmd;
	ASSERT_EQ(TRUE, cmd_init(&cmd, set_str, can_set_str_if_not_set, NULL));
	ASSERT_EQ(TRUE, vm_reg_command(this->vm, CMD_TEST0, &cmd));
	ASSERT_EQ(TRUE, vm_can_execute(this->vm, CMD_TEST0));
	ASSERT_EQ(ERRNO_OK, vm_execute(this->vm, CMD_TEST0, (void*)"executed"));
	ASSERT_EQ(FALSE, vm_can_execute(this->vm, CMD_TEST0));
	ASSERT_EQ(TRUE, vm_unreg_command(this->vm, CMD_TEST0));
}

TEST_F(ViewModelTest, regUnRegCommandFail) {
	Command cmd;
	ASSERT_EQ(FALSE, vm_reg_command(this->vm, INVALID_CMD, &cmd));
	ASSERT_EQ(FALSE, vm_can_execute(this->vm, INVALID_CMD));
	ASSERT_EQ(ERRNO_INVALID_PARAMS, vm_execute(this->vm, INVALID_CMD, (void*)"executed"));
}

static void on_event(void* ctx, PropChangeEvent* e) {
	PropChangeEvent* out = (PropChangeEvent*)ctx;

	out->type = e->type;
	out->prop = e->prop;
	out->value = e->value;
}

TEST_F(ViewModelTest, notify) {
	PropChangeEvent out;
	GValue value;
	gvalue_init_with_int32(&value, PROP0_VALUE);
	ASSERT_EQ(TRUE, vm_on_change(this->vm, on_event, &out));
	ASSERT_EQ(TRUE, vm_set_prop(this->vm, PROP0, &value));
	ASSERT_EQ((int)PROP0, (int)out.prop);
	ASSERT_EQ(PROP0_VALUE, gvalue_get_int32(out.value));	
	ASSERT_EQ(TRUE, vm_off_change(this->vm, on_event, &out));
}

TEST_F(ViewModelTest, notifyFail) {
	ASSERT_EQ(FALSE, vm_on_change(NULL, NULL, NULL));
	ASSERT_EQ(FALSE, vm_off_change(NULL, NULL, NULL));
	ASSERT_EQ(FALSE, vm_on_change(this->vm, NULL, NULL));
	ASSERT_EQ(FALSE, vm_off_change(this->vm, NULL, NULL));
}
