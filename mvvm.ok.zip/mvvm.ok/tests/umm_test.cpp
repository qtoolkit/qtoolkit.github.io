#include <stdio.h>
#include <stdlib.h>
#include "gtest/gtest.h"
extern "C" {
#include "umm_malloc.h"
};

TEST(umm, allocfreeLarge) {
	char mem[1024] = {0};
	umm_init(mem, sizeof(mem));
	char* addr = (char*)umm_malloc(128);
	size_t heap_size = umm_free_heap_size();
	EXPECT_EQ(heap_size, 880);
	umm_free(addr);
}

TEST(umm, allocfreeSmall) {
	char mem[1024] = {0};
	umm_init(mem, sizeof(mem));
	char* addr = (char*)umm_malloc(8);
	size_t heap_size = umm_free_heap_size();
	EXPECT_EQ(heap_size, 1000);
	umm_free(addr);
}
