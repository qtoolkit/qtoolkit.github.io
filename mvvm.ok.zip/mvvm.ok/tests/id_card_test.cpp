#include <stdio.h>
#include <stdlib.h>
#include "gtest/gtest.h"
#include "view_model.h"
#include "id_card.h"
#include "consts.h"

#define ID_CARD0 "111111"

static char mem[1024] = {0};
class IdCardTest: public testing::Test {
protected:
	virtual void SetUp() {
		memset(mem, 0x00, sizeof(mem));
		allocator_init(mem, sizeof(mem));
		this->vm = vm_create(allocator_default(), PROP_NR, CMD_NR); 
		id_card_init(this->vm);
	}

	virtual void TearDown() {
		vm_destroy(this->vm);
	}

	ViewModel* vm;
};

static void on_event(void* ctx, PropChangeEvent* e) {
	*(uint32_t*)ctx = gvalue_get_uint32(e->value);
}

TEST_F(IdCardTest, checkRegCmds) {
	ASSERT_EQ(TRUE, vm_can_execute(this->vm, CMD_ID_CARD_ADD)); 	
	ASSERT_EQ(TRUE, vm_can_execute(this->vm, CMD_ID_CARD_REMOVE)); 	
	ASSERT_EQ(TRUE, vm_can_execute(this->vm, CMD_ID_CARD_OPEN)); 	
}

TEST_F(IdCardTest, unlockFail) {
	uint32_t status = 0xffff;
	vm_on_change(this->vm, on_event, &status);
	ASSERT_EQ(ERRNO_NOT_FOUND, vm_execute(this->vm, CMD_ID_CARD_OPEN, (void*)ID_CARD0)); 	
	ASSERT_EQ(status, (uint32_t)STATUS_ERROR);
	vm_off_change(this->vm, on_event, &status);
}

TEST_F(IdCardTest, unlockOK) {
	uint32_t status = 0xffff;
	vm_on_change(this->vm, on_event, &status);
	ASSERT_EQ(ERRNO_OK, vm_execute(this->vm, CMD_ID_CARD_ADD, (void*)ID_CARD0)); 	
	ASSERT_EQ(ERRNO_OK, vm_execute(this->vm, CMD_ID_CARD_OPEN, (void*)ID_CARD0)); 	
	ASSERT_EQ(status, (uint32_t)STATUS_UNLOCK);
	ASSERT_EQ(ERRNO_OK, vm_execute(this->vm, CMD_ID_CARD_REMOVE, (void*)ID_CARD0)); 	
	vm_off_change(this->vm, on_event, &status);
}

