#include <stdio.h>
#include <stdlib.h>
#include "gtest/gtest.h"
#include "emitter.h"

static char mem[1024] = {0};

class EmitterTest : public testing::Test {
protected:
	virtual void SetUp() {
		memset(mem, 0x00, sizeof(mem));
		allocator_init(mem, sizeof(mem));
		this->emitter = emitter_create(allocator_default());
	}
	virtual void TearDown() {
		emitter_destroy(this->emitter);
	}

	Emitter* emitter;
};


static void on_event(void* ctx, Event* evt) {
	EXPECT_EQ(ctx, evt);	
}
static GValue value;
static PropChangeEvent propChangeEvent = {
	.type = EVENT_PROP_CHANGED,
	.prop = 1,
	.value = &value
};
static Event* evt = (Event*)&propChangeEvent;

TEST_F(EmitterTest, onOff) {
	EXPECT_EQ(TRUE, emitter_on(this->emitter, EVENT_PROP_CHANGED, on_event, evt));
	EXPECT_EQ(1, emitter_count(this->emitter, EVENT_PROP_CHANGED));
	EXPECT_EQ(TRUE, emitter_off(this->emitter, EVENT_PROP_CHANGED, on_event, evt));
	EXPECT_EQ(0, emitter_count(this->emitter, EVENT_PROP_CHANGED));
	EXPECT_EQ(FALSE, emitter_off(this->emitter, EVENT_PROP_CHANGED, on_event, evt));
}

TEST_F(EmitterTest, emit) {
	emitter_on(this->emitter, EVENT_PROP_CHANGED, on_event, evt);
	emitter_emit(this->emitter, evt);
	emitter_off(this->emitter, EVENT_PROP_CHANGED, on_event, evt);
}
