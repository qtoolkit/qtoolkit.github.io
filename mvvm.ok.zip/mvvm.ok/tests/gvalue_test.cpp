#include "gvalue.h"
#include "gtest/gtest.h"

TEST(gvalue, int8_t) {
	GValue v;
	GValue* gv = &v;
	int8_t value = 1;
	gvalue_init_with_int8(gv, value);
	EXPECT_EQ(value, gvalue_get_int8(gv));
}

TEST(gvalue, uint8_t) {
	GValue v;
	GValue* gv = &v;
	uint8_t value = 0x12;
	gvalue_init_with_uint8(gv, value);
	EXPECT_EQ(value, gvalue_get_uint8(gv));
}

TEST(gvalue, int16_t) {
	GValue v;
	GValue* gv = &v;
	int16_t value = 0x12;
	gvalue_init_with_int16(gv, value);
	EXPECT_EQ(value, gvalue_get_int16(gv));
}

TEST(gvalue, uint16_t) {
	GValue v;
	GValue* gv = &v;
	uint16_t value = 0x12;
	gvalue_init_with_uint16(gv, value);
	EXPECT_EQ(value, gvalue_get_uint16(gv));
}

TEST(gvalue, int32_t) {
	GValue v;
	GValue* gv = &v;
	int32_t value = 0x12;
	gvalue_init_with_int32(gv, value);
	EXPECT_EQ(value, gvalue_get_int32(gv));
}

TEST(gvalue, uint32_t) {
	GValue v;
	GValue* gv = &v;
	uint32_t value = 0x12;
	gvalue_init_with_uint32(gv, value);
	EXPECT_EQ(value, gvalue_get_uint32(gv));
}

TEST(gvalue, pointer_t) {
	GValue v;
	GValue* gv = &v;
	pointer_t value = &v;
	gvalue_init_with_pointer(gv, value);
	EXPECT_EQ(value, gvalue_get_pointer(gv));
}

TEST(gvalue, float32_t) {
	GValue v;
	GValue* gv = &v;
	float32_t value = 0x12;
	gvalue_init_with_float32(gv, value);
	EXPECT_EQ(value, gvalue_get_float32(gv));
}

TEST(gvalue, floa64_t) {
	GValue v;
	GValue* gv = &v;
	floa64_t value = 0x12;
	gvalue_init_with_float64(gv, value);
	EXPECT_EQ(value, gvalue_get_float64(gv));
}

TEST(gvalue, object) {
	GValue v;
	GValue* gv = &v;
	GObject value = gobject_init(NULL, NULL);
	gvalue_init_with_object(gv, &value);
	EXPECT_EQ(&value, gvalue_get_object(gv));
}

