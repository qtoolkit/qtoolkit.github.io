export DYLD_LIBRARY_PATH=../base:../app
export LD_LIBRARY_PATH=../base:../app
./runTest
