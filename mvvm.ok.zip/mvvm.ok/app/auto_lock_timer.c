
#include "consts.h"
#include "view_model.h"

static void auto_lock_timer_on_prop_change(void* ctx, PropChangeEvent* evt) {
	if(evt->prop != PROP_STATUS) {
		return;
	}

	uint32_t value = gvalue_get_uint32(evt->value);
	
	switch(value) {
		case STATUS_LOCK : {
			printf("auto_lock_timer: no action\n");
			break;
		}
		case STATUS_UNLOCK : {
			printf("auto_lock_timer: start auto lock timer\n");
			break;
		}
		case STATUS_ERROR: {
			printf("auto_lock_timer: no action\n");
			break;
		}
	}
}

bool_t auto_lock_timer_init(ViewModel* vm) {
	vm_on_change(vm, auto_lock_timer_on_prop_change, NULL);

	return TRUE;
}

