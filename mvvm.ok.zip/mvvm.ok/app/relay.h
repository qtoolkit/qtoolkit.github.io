#ifndef RELAY_H
#define RELAY_H

BEGIN_C_DECLS

bool_t relay_init(ViewModel* vm);

END_C_DECLS

#endif//RELAY_H
