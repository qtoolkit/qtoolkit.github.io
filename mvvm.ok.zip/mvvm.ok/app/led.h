#ifndef LED_H
#define LED_H

BEGIN_C_DECLS

bool_t led_init(ViewModel* vm);

END_C_DECLS

#endif//LED_H
