#ifndef BUZZER_H
#define BUZZER_H

BEGIN_C_DECLS

bool_t buzzer_init(ViewModel* vm);

END_C_DECLS

#endif//BUZZER_H
