
#include "consts.h"
#include "view_model.h"

static void buzzer_on_prop_change(void* ctx, PropChangeEvent* evt) {
	if(evt->prop != PROP_STATUS) {
		return;
	}

	uint32_t value = gvalue_get_uint32(evt->value);
	
	switch(value) {
		case STATUS_LOCK : {
			printf("buzzer: locked\n");
			break;
		}
		case STATUS_UNLOCK : {
			printf("buzzer: unlocked\n");
			break;
		}
		case STATUS_ERROR: {
			printf("buzzer: \033[5merror\033[0m\n");
			break;
		}
	}
}

bool_t buzzer_init(ViewModel* vm) {
	vm_on_change(vm, buzzer_on_prop_change, NULL);

	return TRUE;
}

