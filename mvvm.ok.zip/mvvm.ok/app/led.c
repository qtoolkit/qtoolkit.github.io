
#include "consts.h"
#include "view_model.h"

static void led_on_prop_change(void* ctx, PropChangeEvent* evt) {
	if(evt->prop != PROP_STATUS) {
		return;
	}

	uint32_t value = gvalue_get_uint32(evt->value);
	
	switch(value) {
		case STATUS_LOCK : {
			printf("led: \033[0;31mlocked\033[0m\n");
			break;
		}
		case STATUS_UNLOCK : {
			printf("led: \033[0;31munlocked\033[0m\n");
			break;
		}
		case STATUS_ERROR: {
			printf("led: \033[5merror\033[0m\n");
			break;
		}
	}
}

bool_t led_init(ViewModel* vm) {
	vm_on_change(vm, led_on_prop_change, NULL);

	return TRUE;
}

