#include "id_card.h"

#define ID_LENGTH 6
#define MAX_ID_CARDS_NR 10

static Command cmdAdd;
static Command cmdOpen;
static Command cmdRemove;

static uint8_t invalid_id[ID_LENGTH];
static uint8_t id_cards[MAX_ID_CARDS_NR][ID_LENGTH];

static errno_t id_card_open(Command* cmd, void* args) {
	GValue v;
	errno_t ret = ERRNO_NOT_FOUND;
	ViewModel* vm = (ViewModel*)cmd->ctx;
	
	gvalue_init_with_uint32(&v, STATUS_ERROR);
	for(size_t i = 0; i < MAX_ID_CARDS_NR; i++) {
		uint8_t* iter = id_cards[i];
		if(memcmp(iter, args, ID_LENGTH) == 0) {
			gvalue_init_with_uint32(&v, STATUS_UNLOCK);
			ret = ERRNO_OK;
			break;
		}
	}
	
	vm_set_prop(vm, PROP_STATUS, &v);

	return ret;
}

static errno_t id_card_add(Command* cmd, void* args) {
	for(size_t i = 0; i < MAX_ID_CARDS_NR; i++) {
		uint8_t* iter = id_cards[i];

		if(memcmp(iter, invalid_id, ID_LENGTH) == 0) {
			memcpy(iter, args, ID_LENGTH);
			return ERRNO_OK;
		}
	}

	return ERRNO_NO_SPACE;
}

static errno_t id_card_remove(Command* cmd, void* args) {
	for(size_t i = 0; i < MAX_ID_CARDS_NR; i++) {
		uint8_t* iter = id_cards[i];

		if(memcmp(iter, args, ID_LENGTH) == 0) {
			memcpy(iter, invalid_id, ID_LENGTH);
			return ERRNO_OK;
		}
	}

	return ERRNO_NOT_FOUND;
}

static bool_t id_card_reset() {
	memset(invalid_id, 0x00, ID_LENGTH);

	for(size_t i = 0; i < MAX_ID_CARDS_NR; i++) {
		uint8_t* iter = id_cards[i];
		memcpy(iter, invalid_id, ID_LENGTH);
	}

	return TRUE;
}

bool_t id_card_init(ViewModel* vm) {
	id_card_reset();

	cmd_init(&cmdAdd, id_card_add, NULL, vm);
	cmd_init(&cmdOpen, id_card_open, NULL, vm);
	cmd_init(&cmdRemove, id_card_remove, NULL, vm);

	vm_reg_command(vm, CMD_ID_CARD_ADD, &cmdAdd);
	vm_reg_command(vm, CMD_ID_CARD_OPEN, &cmdOpen);
	vm_reg_command(vm, CMD_ID_CARD_REMOVE, &cmdRemove);

	return TRUE;
}


