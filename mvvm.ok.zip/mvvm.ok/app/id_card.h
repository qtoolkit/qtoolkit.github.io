#ifndef ID_CARD_H
#define ID_CARD_H

#include "consts.h"
#include "view_model.h"

BEGIN_C_DECLS

bool_t id_card_init(ViewModel* vm);

END_C_DECLS

#endif//ID_CARD_H

