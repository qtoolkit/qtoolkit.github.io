#ifndef AUTO_LOCK_TIMER_H
#define AUTO_LOCK_TIMER_H

BEGIN_C_DECLS

bool_t auto_lock_timer_init(ViewModel* vm);

END_C_DECLS

#endif//AUTO_LOCK_TIMER_H
