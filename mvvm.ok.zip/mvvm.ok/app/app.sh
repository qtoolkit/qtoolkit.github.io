export DYLD_LIBRARY_PATH=../base
export LD_LIBRARY_PATH=../base
./runApp
