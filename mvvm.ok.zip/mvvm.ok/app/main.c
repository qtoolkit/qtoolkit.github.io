#include "consts.h"
#include "allocator.h"
#include "view_model.h"

#include "led.h"
#include "relay.h"
#include "buzzer.h"
#include "id_card.h"
#include "auto_lock_timer.h"

typedef bool_t (*ModuleInitFunc)(ViewModel* vm);
static ModuleInitFunc modules[] = {
	led_init,            
	relay_init,         
	buzzer_init,       
	id_card_init,     
	auto_lock_timer_init
};

static bool_t dispatch_cmds(ViewModel* vm, const char* line) {
	if(strncmp(line, "quit", 4) == 0) {
		return FALSE;
	}

	int cmd_id = atoi(line);
	if(vm_can_execute(vm, cmd_id)) {
		errno_t ret = vm_execute(vm, cmd_id, (void*)(line + 2));
		printf("Command(%d) return %d.\n", cmd_id, ret);
	}else{
		printf("Command(%d)\n", cmd_id);
	}
	allocator_debug_info();

	return TRUE;
}

static void show_usage() {
	printf("Usage:\n");
	printf(" ID Card(Open)：0 [6 Bytes ID]\n");
	printf(" ID Card(Add)：1 [6 Bytes ID]\n");
	printf(" ID Card(Remove)：2 [6 Bytes ID]\n");
	printf("Input:");
}

int main(int argc, char* argv[]) {
	char mem[512];
	memset(mem, 0x00, sizeof(mem));
	allocator_init(mem, sizeof(mem));
	ViewModel* vm = vm_create(allocator_default(), PROP_NR, CMD_NR);

	for(size_t i = 0; i < sizeof(modules)/sizeof(modules[0]); i++) {
		if(!modules[i](vm)) {
			printf("init %zuth module failed.\n", i);
		}
	}
	
	char line[1024] = {0};
	while(1) {
		show_usage();
		
		fgets(line, sizeof(line), stdin);
		if(!dispatch_cmds(vm, line)) {
			break;
		}
	}

	vm_destroy(vm);

	return 0;
}
