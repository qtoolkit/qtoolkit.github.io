
#include "consts.h"
#include "view_model.h"

static void relay_on_prop_change(void* ctx, PropChangeEvent* evt) {
	if(evt->prop != PROP_STATUS) {
		return;
	}

	uint32_t value = gvalue_get_uint32(evt->value);
	
	switch(value) {
		case STATUS_LOCK : {
			printf("relay: lock\n");
			break;
		}
		case STATUS_UNLOCK : {
			printf("relay: unlock\n");
			break;
		}
		case STATUS_ERROR: {
			printf("relay: no action\n");
			break;
		}
	}
}

bool_t relay_init(ViewModel* vm) {
	vm_on_change(vm, relay_on_prop_change, NULL);

	return TRUE;
}

